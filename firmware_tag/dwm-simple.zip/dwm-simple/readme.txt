dwm-simple.c

Purpose: Simple example displaying the postion and ranges of the tag. 

Entry function: app_thread_entry

Descriptions:

This simple-example introduces the basics of user-application within PANS firmware.
At startup, the accelerometer is tested with an ID read. If succesful, the result is displated on UART.

For more information of the APIs, please refer to DWM1001_API_Guide